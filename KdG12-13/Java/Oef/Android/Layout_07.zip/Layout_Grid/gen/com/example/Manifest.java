package com.example;

/* This stub is for using by IDE only. It is NOT the Manifest class actually packed into APK */
public final class Manifest {
}